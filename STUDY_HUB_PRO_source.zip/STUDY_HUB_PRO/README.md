# STUDY HUB PRO — Android starter project

This is an Android Studio source project for a dark/black + gold study-platform directory.

## Included
- Bihar Board / Classes 9–12 branding
- Searchable platform grid
- Special and all-platform sections
- WebView shell for in-app HTTPS pages
- Android back navigation

## Important: platform links are not yet configured
The screenshots provide platform names/design references, not verified official URLs.
Add verified official HTTPS URLs in:
`app/src/main/assets/platforms.js`

Use each provider's official website or an authorized class portal. Some providers may block embedded WebViews, require their official app, or require a separate login. Do not copy paid course videos or bypass access controls.

## Build an APK
1. Open this folder in Android Studio.
2. Let Gradle sync.
3. Choose Build → Build Bundle(s) / APK(s) → Build APK(s).
4. Android Studio will show the generated APK location.

This deliverable is the editable source project, not a prebuilt/installable APK.
