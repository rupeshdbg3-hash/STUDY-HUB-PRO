// Add only official HTTPS URLs that you are authorized to use.
// Example: const PLATFORM_URLS = { "PW": "https://www.pw.live/" };
const PLATFORM_URLS = {};
